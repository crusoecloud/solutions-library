# Fluent Bit Helm Chart Changelog

> [!NOTE]
> All notable changes to this project will be documented in this file; the format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

<!--
### Added - For new features.
### Changed - For changes in existing functionality.
### Deprecated - For soon-to-be removed features.
### Removed - For now removed features.
### Fixed - For any bug fixes.
### Security - In case of vulnerabilities.
-->

## [UNRELEASED]

## [v0.58.3] - 2026-10-01

### Changed

- Update _Fluent Bit_ OCI image to [v5.1.3](https://github.com/fluent/fluent-bit/releases/tag/v5.1.3). ([#759](https://github.com/fluent/helm-charts/pull/759)) @stevehipwell

## [v0.58.2] - 2026-09-08

### Changed

- Update _Fluent Bit_ OCI image to [v5.1.2](https://github.com/fluent/fluent-bit/releases/tag/v5.1.2). ([#755](https://github.com/fluent/helm-charts/pull/755)) @stevehipwell

## [v0.58.1] - 2026-08-17

### Changed

- Update _Fluent Bit_ OCI image to [v5.1.1](https://github.com/fluent/fluent-bit/releases/tag/v5.1.1). ([#752](https://github.com/fluent/helm-charts/pull/752)) @stevehipwell

## [v0.58.0] - 2026-08-12

### Changed

- Update _Fluent Bit_ OCI image to [v5.1.0](https://github.com/fluent/fluent-bit/releases/tag/v5.1.0). ([#749](https://github.com/fluent/helm-charts/pull/749)) @stevehipwell

## [v0.57.9] - 2026-07-06

### Changed

- Update _Fluent Bit_ OCI image to [v5.0.9](https://github.com/fluent/fluent-bit/releases/tag/v5.0.9). ([#736](https://github.com/fluent/helm-charts/pull/736)) _@stevehipwell_

## [v0.57.8] - 2026-07-01

### Changed

- Update _Fluent Bit_ OCI image to [v5.0.8](https://github.com/fluent/fluent-bit/releases/tag/v5.0.8). ([#734](https://github.com/fluent/helm-charts/pull/734)) _@stevehipwell_

## [v0.57.7] - 2026-06-08

### Changed

- Update _Fluent Bit_ OCI image to [v5.0.7](https://github.com/fluent/fluent-bit/releases/tag/v5.0.7). ([#729](https://github.com/fluent/helm-charts/pull/729)) _@stevehipwell_

## [v0.57.6] - 2026-05-22

### Changed

- Update _Fluent Bit_ OCI image to [v5.0.6](https://github.com/fluent/fluent-bit/releases/tag/v5.0.6). ([#724](https://github.com/fluent/helm-charts/pull/724)) _@stevehipwell_

## [v0.57.5] - 2026-05-12

### Changed

- Update _Fluent Bit_ OCI image to [v5.0.5](https://github.com/fluent/fluent-bit/releases/tag/v5.0.5). ([#721](https://github.com/fluent/helm-charts/pull/721)) _@stevehipwell_

## [v0.57.4] - 2026-05-12

### Changed

- Update _Fluent Bit_ OCI image to [v5.0.4](https://github.com/fluent/fluent-bit/releases/tag/v5.0.4). ([#719](https://github.com/fluent/helm-charts/pull/719)) _@stevehipwell_

## [v0.57.3] - 2026-04-17

### Changed

- Update _Fluent Bit_ OCI image to [v5.0.3](https://github.com/fluent/fluent-bit/releases/tag/v5.0.3). ([#710](https://github.com/fluent/helm-charts/pull/710)) _@stevehipwell_

## [v0.57.2] - 2026-04-02

### Changed

- Update _Fluent Bit_ OCI image to [v5.0.2](https://github.com/fluent/fluent-bit/releases/tag/v5.0.2). ([#705](https://github.com/fluent/helm-charts/pull/705)) _@stevehipwell_

## [v0.57.1] - 2026-04-02

### Changed

- Update _Fluent Bit_ OCI image to [v5.0.1](https://github.com/fluent/fluent-bit/releases/tag/v5.0.1). ([#704](https://github.com/fluent/helm-charts/pull/704)) _@stevehipwell_

## [v0.57.0] - 2026-03-23

### Changed

- Update _Fluent Bit_ OCI image to [v5.0.0](https://github.com/fluent/fluent-bit/releases/tag/v5.0.0). ([#700](https://github.com/fluent/helm-charts/pull/700)) _@stevehipwell_

## [v0.56.0] - 2026-02-27

### Added

- VPA recommender may be specified with `.autoscaling.vpa.recommender`

## [v0.55.1] - 2026-02-27

### Changed

- Update _Fluent Bit_ OCI image to [v4.2.3](https://github.com/fluent/fluent-bit/releases/tag/v4.2.3). ([#697](https://github.com/fluent/helm-charts/pull/697)) _@stevehipwell_

## [v0.55.0] - 2026-01-22

### Changed

- Update Fluent Bit OCI image to [4.2.2](https://github.com/fluent/fluent-bit/releases/tag/v4.2.2). ([#684](https://github.com/fluent/helm-charts/pull/684)) _@stevehipwell_

## [v0.54.1] - 2026-01-06

### Changed

- Update Fluent Bit OCI image to [4.1.1](https://github.com/fluent/fluent-bit/releases/tag/v4.1.1). ([#639](https://github.com/fluent/helm-charts/pull/666)) _@Xelus22_

## [v0.54.0] - 2025-10-09

### Changed

- Update Fluent Bit OCI image to [4.1.0](https://github.com/fluent/fluent-bit/releases/tag/v4.1.0). ([#639](https://github.com/fluent/helm-charts/pull/639)) _@timonegk_

<!--
RELEASE LINKS
-->

[UNRELEASED]: https://github.com/fluent/helm-charts/tree/main/charts/fluent-bit
[v0.58.3]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.58.3
[v0.58.2]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.58.2
[v0.58.1]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.58.1
[v0.58.0]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.58.0
[v0.57.9]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.57.9
[v0.57.8]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.57.8
[v0.57.7]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.57.7
[v0.57.6]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.57.6
[v0.57.5]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.57.5
[v0.57.4]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.57.4
[v0.57.3]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.57.3
[v0.57.2]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.57.2
[v0.57.1]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.57.1
[v0.57.0]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.57.0
[v0.56.0]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.56.0
[v0.55.1]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.55.1
[v0.55.0]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.55.0
[v0.54.1]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.54.1
[v0.54.0]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.54.0
