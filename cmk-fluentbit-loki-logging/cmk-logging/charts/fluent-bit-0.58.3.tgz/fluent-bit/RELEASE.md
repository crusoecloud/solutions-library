
### Changed

- Update _Fluent Bit_ OCI image to [v5.1.3](https://github.com/fluent/fluent-bit/releases/tag/v5.1.3). ([#759](https://github.com/fluent/helm-charts/pull/759)) @stevehipwell
